# Litoral Automotores — Demo concesionaria de usados

Demo de prospección hecha por **Sistemas Umbral**. Landing de una sola página, mobile-first, con movimiento sobrio (Lenis) y conversión por WhatsApp directo. Negocio y unidades **ficticios**.

## Estructura

```
demo-concesionaria-usados/
├── index.html            # la página (fuente de verdad)
├── assets/
│   ├── css/styles.css    # sistema de diseño + componentes
│   ├── js/main.js        # Lenis, reveal, filtros, WhatsApp, contadores
│   └── img/              # (vacío) acá van las fotos reales del cliente
├── preview.html          # versión autocontenida en 1 archivo (solo para mostrar rápido)
└── README.md
```

## Qué reemplazar para personalizarla a un cliente real

1. **Número de WhatsApp** → en `assets/js/main.js`, variable `WA_NUMBER` (formato `54` + `9` + área + número, sin signos). Es el único lugar donde se toca.
2. **Nombre y datos del negocio** → nombre, dirección, horarios y textos están en `index.html` (buscá "Litoral Automotores").
3. **Unidades** → cada auto es un bloque `<article class="unit">`. Cambiá modelo, año, km, precio y el mensaje de WhatsApp (`data-wa`).
4. **Fotos** → hoy usa imágenes de stock (Unsplash) por URL. Reemplazalas por las fotos reales del inventario: subilas a `assets/img/` y cambiá el `src` de cada `<img>`. Si una foto no carga, la demo muestra un gradiente de marca automáticamente (nunca una imagen rota).
5. **Color de marca** → una sola variable en `assets/css/styles.css`: `--primary`. Cambiala por el color del logo del cliente y todo el sitio se adapta.
6. **Mapa** → en la sección Contacto, cambiá la dirección en la URL del `iframe`.

## Ver la demo localmente

Abrí `preview.html` directo en el navegador (es autocontenido), o serví la carpeta:

```bash
npx serve .
```

## Desplegar en Vercel

Es un sitio estático, no necesita build.

```bash
npm i -g vercel
vercel        # primera vez, seguí los pasos
vercel --prod # deploy productivo → te da la URL para mostrar
```

O desde el dashboard de Vercel: **Add New → Project → Import**, arrastrás esta carpeta y listo.

## Notas

- La página tiene `noindex` (no la indexa Google) y un aviso de "demostración" en el pie: es a propósito, para no exponerla como si fuera real.
- Respeta `prefers-reduced-motion`: si el usuario pidió menos animación, se desactivan los efectos.
