/* ============================================================
   Litoral Automotores — interacción
   Sistemas Umbral · movimiento sobrio + Lenis
   ============================================================ */
(function () {
  'use strict';

  // ---- Config: número de WhatsApp en UN solo lugar (reemplazar por el real) ----
  var WA_NUMBER = '5493450000000'; // 54 9 + código de área + número, sin signos
  var WA_BASE = 'Hola 👋 Vengo de la web de Litoral Automotores. ';

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ============================================================
  // WhatsApp: construye los links con mensaje pre-armado
  // ============================================================
  function buildWaLinks() {
    document.querySelectorAll('[data-wa]').forEach(function (el) {
      var msg = el.getAttribute('data-wa') || '';
      el.setAttribute('href', 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(WA_BASE + msg));
      el.setAttribute('target', '_blank');
      el.setAttribute('rel', 'noopener');
    });
  }

  // ============================================================
  // Imágenes: fallback a gradiente de marca si alguna no carga
  // (la demo nunca muestra una imagen rota)
  // ============================================================
  function imgFallback() {
    document.querySelectorAll('img[data-fallback]').forEach(function (img) {
      img.addEventListener('error', function () {
        if (img.dataset.failed) return;
        img.dataset.failed = '1';
        var label = img.getAttribute('alt') || '';
        var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600">' +
          '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
          '<stop offset="0" stop-color="#1B1E24"/><stop offset="1" stop-color="#0C0D10"/></linearGradient></defs>' +
          '<rect width="800" height="600" fill="url(#g)"/>' +
          '<path d="M370 220l40 30-40 30" fill="none" stroke="#8B31FF" stroke-width="6" stroke-linecap="square"/>' +
          '<text x="400" y="320" fill="#8B31FF" font-family="sans-serif" font-size="24" text-anchor="middle" font-weight="bold">LITORAL</text>' +
          '<text x="400" y="360" fill="#9A9AA6" font-family="sans-serif" font-size="17" text-anchor="middle">' + label.replace(/[<>&]/g, '') + '</text>' +
          '</svg>';
        img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
      }, { once: true });
    });
  }

  // ============================================================
  // Header: estado al scrollear
  // ============================================================
  function header() {
    var h = document.querySelector('.header');
    var onScroll = function () { h.classList.toggle('scrolled', window.scrollY > 24); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // ============================================================
  // Menú móvil
  // ============================================================
  function mobileNav() {
    var burger = document.querySelector('.burger');
    var menu = document.querySelector('.mobile-nav');
    if (!burger || !menu) return;
    var toggle = function (open) {
      burger.classList.toggle('open', open);
      menu.classList.toggle('open', open);
      document.body.style.overflow = open ? 'hidden' : '';
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    };
    burger.addEventListener('click', function () { toggle(!menu.classList.contains('open')); });
    menu.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { toggle(false); }); });
  }

  // ============================================================
  // WhatsApp flotante: aparece pasado el hero
  // ============================================================
  function waFloat() {
    var f = document.querySelector('.wa-float');
    if (!f) return;
    var onScroll = function () { f.classList.toggle('show', window.scrollY > 640); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // ============================================================
  // Reveal al entrar en pantalla (con stagger)
  // ============================================================
  function reveal() {
    var els = document.querySelectorAll('[data-reveal]');
    if (reduce || !('IntersectionObserver' in window)) {
      els.forEach(function (e) { e.classList.add('in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        var el = en.target;
        var delay = parseInt(el.getAttribute('data-delay') || '0', 10);
        setTimeout(function () { el.classList.add('in'); }, delay);
        io.unobserve(el);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    els.forEach(function (e) { io.observe(e); });
  }

  // ============================================================
  // Contadores animados
  // ============================================================
  function counters() {
    var nums = document.querySelectorAll('[data-count]');
    if (!nums.length) return;
    var run = function (el) {
      var target = parseFloat(el.getAttribute('data-count'));
      var dec = (el.getAttribute('data-count').split('.')[1] || '').length;
      var suffix = el.getAttribute('data-suffix') || '';
      var prefix = el.getAttribute('data-prefix') || '';
      if (reduce) { el.textContent = prefix + target.toLocaleString('es-AR') + suffix; return; }
      var start = null, dur = 1400;
      var step = function (ts) {
        if (!start) start = ts;
        var p = Math.min((ts - start) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        var val = target * eased;
        el.textContent = prefix + (dec ? val.toFixed(dec) : Math.round(val).toLocaleString('es-AR')) + suffix;
        if (p < 1) requestAnimationFrame(step);
        else el.textContent = prefix + (dec ? target.toFixed(dec) : target.toLocaleString('es-AR')) + suffix;
      };
      requestAnimationFrame(step);
    };
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { run(en.target); io.unobserve(en.target); } });
    }, { threshold: 0.6 });
    nums.forEach(function (n) { io.observe(n); });
  }

  // ============================================================
  // Filtro de unidades
  // ============================================================
  function filters() {
    var btns = document.querySelectorAll('.filter');
    var units = document.querySelectorAll('.unit');
    if (!btns.length) return;
    btns.forEach(function (b) {
      b.addEventListener('click', function () {
        btns.forEach(function (x) { x.classList.remove('active'); x.setAttribute('aria-pressed', 'false'); });
        b.classList.add('active'); b.setAttribute('aria-pressed', 'true');
        var f = b.getAttribute('data-filter');
        units.forEach(function (u) {
          var show = f === 'todos' || u.getAttribute('data-cat') === f;
          u.style.display = show ? '' : 'none';
        });
      });
    });
  }

  // ============================================================
  // Lenis smooth scroll + anclas
  // ============================================================
  function smooth() {
    var lenis = null;
    if (!reduce && window.Lenis) {
      lenis = new window.Lenis({ duration: 1.1, smoothWheel: true });
      var raf = function (t) { lenis.raf(t); requestAnimationFrame(raf); };
      requestAnimationFrame(raf);
    }
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var id = a.getAttribute('href');
        if (id.length < 2) return;
        var t = document.querySelector(id);
        if (!t) return;
        e.preventDefault();
        if (lenis) lenis.scrollTo(t, { offset: -74 });
        else t.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
      });
    });
  }

  // ============================================================
  // Init
  // ============================================================
  function init() {
    buildWaLinks();
    imgFallback();
    header();
    mobileNav();
    waFloat();
    reveal();
    counters();
    filters();
    smooth();
    document.getElementById('year') && (document.getElementById('year').textContent = new Date().getFullYear());
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
