// Genera preview.html autocontenido (CSS y JS inline) desde index.html
import fs from 'fs';
const dir = new URL('.', import.meta.url).pathname;
let html = fs.readFileSync(dir + 'index.html', 'utf8');
const css = fs.readFileSync(dir + 'assets/css/styles.css', 'utf8');
const js = fs.readFileSync(dir + 'assets/js/main.js', 'utf8');

html = html.replace('<link rel="stylesheet" href="assets/css/styles.css">', '<style>\n' + css + '\n</style>');
html = html.replace('<script src="assets/js/main.js"></script>', '<script>\n' + js + '\n</script>');

fs.writeFileSync(dir + 'preview.html', html);
console.log('preview.html generado — ' + (html.length / 1024).toFixed(0) + ' KB');
